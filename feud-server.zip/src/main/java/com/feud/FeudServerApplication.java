package com.feud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FeudServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(FeudServerApplication.class, args);
	}

}
