package com.feud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FeudServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
